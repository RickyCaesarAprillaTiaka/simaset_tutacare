<?php

return [

'version' => '0.0.7',
// Laporan -> ok
//laporan pdf -> ok
// 'version' => '0.0.5',
//logout user -> OK
//profil user -> OK
//asset -> OK
];
